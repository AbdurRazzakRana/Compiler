int y,Z[100];

int f(int b)
{ 
 int y;
 {  int x[10];
  x[2+3-5]=b + f(5+x[2]*b);
 }
 {  int x[10];
  x[2+3-5]=b + f(5+x[2]*b);
 }
}

int z;

int main(int arg1, int arg2[])
{
   write  f(arg1 + arg2[3+5] -z + y);
   write  f(arg1 + arg2[3+5] -z + y);


}
