// Shaun Cooper
// Test one

break;
continue;
int main(int a, int b);

int x;
int x,x;

int main(int a, void b, int a[]) { 
 int x , A[100];
    
   read x; 
   read y[ 3+4  ];
   read x; 
   write "helo";
   write 3+4+f(3,2,A[20]) ;  
   return;
    return 3+4+f(3,2,A[20]);
    3+4+f(3,2,A[20]);
    ;;;
    {{while ( x < 3) read x; }}

     read x;
     if ( x ) write 5 ;
     if( x < 3) return 5; else write "great";

} // of main

void f(void) {}

int x , A[100];
void  A[100];
void  A[100], x;
void  A[100], B[2];
